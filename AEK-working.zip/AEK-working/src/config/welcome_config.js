/* 



module.exports = {
  TENANT_ID: "8f9dd54e-1f93-410e-9d8b-2501ed27d2f7",

  CLIENT_ID: "586f8d6b-b974-46b4-a0fe-44ad0021323a",

  CLIENT_SECRET: "f5O8Q~B1SLCdQKmzRwcDKIVUC5X-xfodd3GYRdrT",

  SITE_ID: "genisysconsulting.sharepoint.com,359cc0ee-ba5a-4181-8fa9-749779d58d77,145d03fc-5345-41c6-b5c5-d0cd7601c594",

  DRIVE_ID: "b!7sCcNVq6gUGPqXSXedWNd_wDXRRFU8ZBtcXQzXYBxZSSNOZrvzkzQZJuL9wX92BW",

  DOCUMENT_LIBRARY_NAME: "AIFSDocumentList",

  CAMPUS: "London",

  DOCUMENT_TYPE: "Welcome Pack",

  DOCUMENT_TYPE_FIELD: "DocumentType",

  CAMPUS_FIELD: "Campus",

  PORT: 3001,

  AEK_ORIGIN: "http://localhost:5000"
};




*/











/*
PROXY_URL: "http://localhost:7071/api",
*/



module.exports = {
  PROXY_URL: "https://aek-sharepoint-doc-fetch-bngdcsdwavdqf9gm.uksouth-01.azurewebsites.net/api",
  FUNCTION_KEY: "", // Blank for local development
  DEFAULT_CAMPUS: "Rome", // Change to "Rome" or any campus to test!
  DEFAULT_DOC_TYPE: "Welcome Pack",
  CONTACT_ID: "CGNYHA11PDO5"
};