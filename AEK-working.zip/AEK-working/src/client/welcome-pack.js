import React from "react";
import "react-dom";
import {reactRender} from "@ombiel/aek-lib";

import Screen from "../client/welcome-pack/screen";

reactRender(<Screen />);
